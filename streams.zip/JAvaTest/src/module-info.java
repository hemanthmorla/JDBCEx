/**
 * 
 */
/**
 * @author 503336131
 *
 */
module JAvaTest {
}