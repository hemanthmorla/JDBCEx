package com.failsafe;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class FailSafeIterator2 {  
    
    public static void main(String[] args)   
    {  
        ArrayList<String> students = new ArrayList<String>();   
        students.add("Emma");   
        students.add("Paul");   
        students.add("Walker");  
          
        //creating CopyOnWriteArrayList by copy students ArrayList   
        CopyOnWriteArrayList<String> copyStudents = new CopyOnWriteArrayList<String>(students);   
          
        //creating an instance of the Iterator class  
        Iterator itr = copyStudents.iterator();   
          
        //iterating CopyOnWriteArrayList using Iterator   
        while (itr.hasNext()) {  
            String name = (String)itr.next();   
            System.out.println(name);   
            if (name == "Paul")   
                copyStudents.add("Rubby");  
        }   
        copyStudents.stream().forEach(System.out::println);
    }   
}  
