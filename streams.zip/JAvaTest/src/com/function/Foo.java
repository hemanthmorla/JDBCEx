package com.function;

//@FunctionalInterface
public interface Foo {
    String method(String string);
    
}
