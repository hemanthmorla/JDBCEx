package com.function;

import java.util.function.Function;

public class FunctionTest {
	public static void main(String[] args) {
		UseFoo useFoo = new UseFoo();
		Foo foo = parameter -> parameter + " from lambda";
//		Function<String, String> fn = parameter -> parameter + " from lambda";
		String result = useFoo.add("Message ", foo);
		System.out.println(result);
	}
	
//	public static void main(String[] args) {
//		Function<String,String> f1 = s -> {System.out.println("main");return s;};
//		f1 = f1.andThen(s -> {System.out.println("andThen 1");return s;});
//		f1 = f1.compose(s -> {System.out.println("compose 1");return s;});
//		f1 = f1.andThen(s -> {System.out.println("andThen 2");return s;});
//		f1 = f1.compose(s -> {System.out.println("compose 2");return s;});
//		f1 = f1.andThen(s -> {System.out.println("andThen 3");return s;});
//		f1 = f1.compose(s -> {System.out.println("compose 3");return s;});
//		f1 = f1.andThen(s -> {System.out.println("andThen 4");return s;});
//		f1 = f1.compose(s -> {System.out.println("compose 4");return s;});
//		
//		f1.apply("not important");
//	}
	
//	public static void main(String[] args) {
//		Function<Double, Double> half = (a) -> a / 2;
//		Function<Double, Double> twice = (a) -> a * a;
//		  
//		Function<Double, Double> squareAndThenCube = half.andThen(twice);
//		Double result = squareAndThenCube.apply(3d);
//		System.out.println(result);
//		  
//		Function<Double, Double> squareComposeCube = half.compose(twice);
//		result = squareComposeCube.apply(3d);
//		System.out.println(result);
//	}
	
}
