package com.ToIntFunction;

import java.util.Arrays;
import java.util.List;
import java.util.function.ToIntFunction;

public class ToIntFunctionTest {
	public static void main(String[] args) {
		ToIntFunction<String> toIntFun = String::length;

		List<String> strList = Arrays.asList("hemanth", "Karthik", "Irfan", "Jai");
		for (String str : strList) {
			int length = toIntFun.applyAsInt(str);
			System.out.println(length);
		}
	}
}
