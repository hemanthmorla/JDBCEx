package com.biconsumer;

import java.util.function.BiConsumer;

public class BiConsumerTest {
	public static void main(String[] args) {
		BiConsumer<Integer, Integer> biConsumer = (x, y) -> {
			System.out.println(x + y);
		};
		
		biConsumer.accept(4, 5);
	}
}
