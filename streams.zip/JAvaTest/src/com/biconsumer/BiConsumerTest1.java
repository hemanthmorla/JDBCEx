package com.biconsumer;

import java.util.function.BiConsumer;

public class BiConsumerTest1 {
	public static void main(String[] args) {
		math(1, 1, (x, y) -> System.out.println(x + y));
		math(1, 1, (x, y) -> System.out.println(x - y));
		math(1, 1, (x, y) -> System.out.println(x * y));
		math(1, 1, (x, y) -> System.out.println(x / y));
	}

	static <Integer> void math(Integer a1, Integer a2, BiConsumer<Integer, Integer> c) {
		c.accept(a1, a2);
	}
}
