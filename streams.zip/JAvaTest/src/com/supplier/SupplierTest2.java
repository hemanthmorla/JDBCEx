package com.supplier;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.function.Supplier;

public class SupplierTest2 {
	public static void main(String[] args) {

		Employee obj = factory(Employee::new);
		System.out.println(obj);

		Employee obj2 = factory(() -> new Employee("hemanth"));
		System.out.println(obj2);

	}

	public static Employee factory(Supplier<? extends Employee> s) {

		Employee emp = s.get();
		if (emp.getName() == null || "".equals(emp.getName())) {
			emp.setName("default");
		}
		emp.setSalary(BigDecimal.ONE);
		emp.setStart(LocalDate.of(2023, 8, 8));

		return emp;

	}
}
