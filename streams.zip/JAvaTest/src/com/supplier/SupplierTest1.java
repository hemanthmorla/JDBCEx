package com.supplier;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class SupplierTest1<T> {
	public static void main(String[] args) {
		SupplierTest1<String> obj = new SupplierTest1();
        List<String> list = obj.supplier().get();
        System.out.println(list);
    }

    public Supplier<List<T>> supplier() {
        // lambda
        // return () -> new ArrayList<>();

        // constructor reference
        return ArrayList::new;

    }
}
