package com.failfast;

import java.util.ArrayList;
import java.util.Iterator;

public class FailFastIterator2 {

	public static void main(String[] args) {
		ArrayList<String> students = new ArrayList<String>();
		students.add("Emma");
		students.add("Paul");
		students.add("Walker");
		students.add("Elanie");
		students.add("Amara");

		Iterator itr = students.iterator();

		while (itr.hasNext()) {
			if ((String) itr.next() == "Paul")
				// It will throw an exception on next call of next() method
				students.remove("Amara");
		}

		System.out.println(students);
		itr = students.iterator();
	}
}
