package com.stream;

import java.util.function.Consumer;
import java.util.stream.Stream;

public class MapMultiTest1 {

	static void doWork(String str, Consumer<String> con) {
		for (String ele : str.split(",")) {
			con.accept(ele);
		}
	}

	public static void main(String[] args) {
		var strStream = Stream.of("hello,world", "welcome,java");
		strStream.mapMulti(MapMultiTest1::doWork).toList().forEach(System.out::println);
	}
}
