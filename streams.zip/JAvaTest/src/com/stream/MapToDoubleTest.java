package com.stream;

import java.util.Arrays;
import java.util.List;

public class MapToDoubleTest {
	public static void main(String[] args) {
		List<String> list = Arrays.asList("10", "6.548", "9.12", "11", "15");

		list.stream().mapToDouble(num -> Double.parseDouble(num)).filter(num -> (num * num) * 2 == 450)
				.forEach(System.out::println);
	}
}
