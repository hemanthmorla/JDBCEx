package com.stream;

import java.util.Arrays;
import java.util.List;
import java.util.stream.DoubleStream;

public class FlatMapToDouble {
	public static void main(String[] args) {
		List<String> list = Arrays.asList("1.5", "2.7", "3", "4", "5.6");
		list.stream().flatMapToDouble(num -> DoubleStream.of(Double.parseDouble(num))).forEach(System.out::println);
	}
}
