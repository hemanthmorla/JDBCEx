package com.stream;

import java.util.stream.Stream;

public class WhileTest {
	public static void main(String[] args) {
		Stream<String> stream = Stream.iterate("", s -> s + "s").takeWhile(s -> s.length() < 10);
		stream.forEach(System.out::println);
	}
}
