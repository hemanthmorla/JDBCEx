package com.stream;

import java.util.Arrays;
import java.util.List;

public class PeekTest {
	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(1, 3, 5, 7, 12);
//		list.stream().forEach(System.out::println);
		long c = list.stream().peek(System.out::println).count();
		System.out.println(c);
		
//		Why peek() print nothing?
//		Since Java 9, if JDK compiler is able computing the count directly from the stream (optimization in Java 9), it didn’t traverse the stream, so there is no need to run peek() at all.
//		how to print then ? To force the peek() to run, just alter some elements with filter() or switch to another terminal operation like collect()
		
		long c1 = list.stream().filter(i -> i.intValue() > 0).peek(System.out::println).count();
		System.out.println(c1);
	}
}
