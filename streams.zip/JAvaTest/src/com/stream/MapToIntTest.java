package com.stream;

import java.util.Arrays;
import java.util.List;

public class MapToIntTest {
	public static void main(String[] args) {
		List<String> list = Arrays.asList("3", "6", "8", "14", "15");
		list.stream().mapToInt(num -> Integer.parseInt(num)).filter(num -> num % 2 == 0).forEach(System.out::println);
//		Or using method reference
		list.stream().mapToInt(Integer::parseInt).filter(num -> num % 2 == 0).forEach(System.out::println);
	}
	
}
