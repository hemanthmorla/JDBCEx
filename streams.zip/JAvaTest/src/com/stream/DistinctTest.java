package com.stream;

import java.util.Arrays;
import java.util.List;

public class DistinctTest {
	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(1, 1, 2, 3, 3, 4, 5, 5);
		list.stream().distinct().forEach(System.out::println);
		long distCount = list.stream().distinct().count();
		System.out.println("Distinct elements count: " + distCount);
	}
}
