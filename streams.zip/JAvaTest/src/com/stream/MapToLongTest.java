package com.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.function.ToLongFunction;

public class MapToLongTest {
	public static void main(String[] args) {
		List<Long> longList = new ArrayList<>();
		longList.add(10L);
		longList.add(4323L);
		longList.add(8987L);

		ToLongFunction<Long> multiplyByTwo = e -> e * 2;

		longList.stream().mapToLong(multiplyByTwo).forEach(System.out::println);
	}
}
