package com.stream;

import java.util.stream.Stream;

//Notes:
//		<R> Stream<R> mapMulti​(BiConsumer<T, Consumer<R>> mapper)
//	1. It’s a Stream intermediate operation. 
//	2. It requires as a parameter the implementation of a BiConsumer functional interface.
//	3. The implementation of the BiConsumer takes a Stream element T, if necessary, transforms it into type R, and invokes the mapper’s Consumer::accept.
//	4. Each time we invoke Consumer::accept, it accumulates the elements in the buffer and passes them to the stream pipeline.
public class MapMultiTest {
	public static void main(String[] args) {
		Stream.of("hemanth", "ravi", "guru").mapMulti((s, c) -> {
			c.accept(s.toUpperCase());
			c.accept(s.toLowerCase());
		}).forEach(System.out::println);
		
		Stream.of("hemanth", "ravi", "guru")
		  .flatMap(s -> Stream.of(s.toUpperCase(), s.toLowerCase()))
		  .forEach(System.out::println);
		
//		Both creates same output but what is the difference:
//			Using mapMulti method avoids the overhead of creating a new Stream instance for every group of result elements, as required by flatMap.
	}
}
