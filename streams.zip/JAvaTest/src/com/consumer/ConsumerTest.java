package com.consumer;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

//Consumer: Takes something, does something, returns nothing: void accept(T t)
public class ConsumerTest {
//	public static void main(String[] args) {
//		Consumer<String> con = (str) -> System.out.print(str);
//		Consumer<String> thenCon = (str) -> System.out.println(str.length());
//		
//		List<String> list = Arrays.asList("Andhra","Hyderabad","Chennai","Pune","Delhi");
//		list.stream().forEach(con.andThen(thenCon));
//	}
	
	public static void main(String[] args) {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5);
        Consumer<Integer> consumer = (Integer x) -> System.out.println(x);
        doWork(list, consumer);
    }

    static <T> void doWork(List<T> list, Consumer<T> consumer) {
        for (T t : list) {
            consumer.accept(t);
        }
    }
}
