package com.sort;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class SortedTest {

//	Traditional way of sorting before java 8
	public static void main(String[] args) {
		
		List<Human> humans = Arrays.asList(
			      new Human("ravi", 12),
			      new Human("hemanth", 10),
			      new Human("avi", 6)
			    );
		
// Anonymous inner class for Comparator.
		// Internally Collections.sort(..) class List.sort(..) method only.
		Collections.sort(humans, new Comparator<Human>() {
			@Override
			public int compare(Human h1, Human h2) {
				return h1.getAge().compareTo(h2.getAge());
			}
	    });
		
		System.out.println(humans);
	}
}
