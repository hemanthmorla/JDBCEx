package com.sort;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

//	if the collection contains at least one null element, then the sort method throws a NullPointerException.
//	How to handle?
public class SortedTest3 {
	public static void main(String[] args) {
		List<Human> humans = Arrays.asList(null, new Human("ravi", 12), null, new Human("hemanth", 10),
				new Human("avi", 6));
//		Below statement throws NullPointerException.
//		humans.sort((h1, h2) -> h1.getName().compareTo(h2.getName()));

//	Way-- 1 : handling the null values manually.
//		Here we’re pushing all null elements towards the end of the collection. 
//		So the comparator considers null to be greater than non-null values. When both are null, they are considered equal.
		humans.sort((h1, h2) -> {
			if (h1 == null) {
				return h2 == null ? 0 : 1;
			} else if (h2 == null) {
				return -1;
			}
			return h1.getAge().compareTo(h2.getAge());
		});
		System.out.println(humans);

//		Way-- 2: The above functionality can be achieved by below:
		List<Human> humans1 = Arrays.asList(null, new Human("ravi", 12), null, new Human("hemanth", 10),
				new Human("avi", 6));
		humans1.sort(Comparator.nullsLast(Comparator.comparing(Human::getAge)));
		System.out.println(humans1);
//		OR, by using streams
		humans1.stream().sorted(Comparator.nullsLast(Comparator.comparing(Human::getAge))).forEach(System.out::println);
		
//		Way-- 3 : Putting null first.
		List<Human> humans2 = Arrays.asList(null, new Human("ravi", 12), null, new Human("hemanth", 10),
				new Human("avi", 6));
		humans2.sort(Comparator.nullsFirst(Comparator.comparing(Human::getAge)));
		System.out.println(humans2);
		
//		It’s highly recommended to use the nullsFirst() or nullsLast() decorators, as they’re more flexible and readable.
	}
}
