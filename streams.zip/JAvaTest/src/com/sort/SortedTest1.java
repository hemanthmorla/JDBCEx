package com.sort;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class SortedTest1 {

	public static int compareByAge(Human h1, Human h2) {
		return Integer.compare(h1.getAge(), h2.getAge());
	}

//	As Collections.sort(..) method internally calls List.sort(..) method, so it is always good to work with List.sort(..) method 
	public static void main(String[] args) {
//		Using sort method of List interface since 1.8 
		List<Human> humans = Arrays.asList(new Human("ravi", 12), new Human("hemanth", 10), new Human("avi", 6));
		humans.sort(((h1, h2) -> h1.getAge().compareTo(h2.getAge())));
		System.out.println(humans);

//		Sort Using reference to Static Method
		List<Human> humans2 = Arrays.asList(new Human("ravi", 12), new Human("hemanth", 10), new Human("avi", 6));
		humans2.sort(SortedTest1::compareByAge);
		System.out.println(humans2);

//		Using Comparator.comparing method
		List<Human> humans3 = Arrays.asList(new Human("ravi", 12), new Human("hemanth", 10), new Human("avi", 6));
		humans3.sort(Comparator.comparing(Human::getAge));
		System.out.println(humans3);

//		Reverse sort
		Comparator<Human> comparator = (h1, h2) -> h1.getAge().compareTo(h2.getAge());
		humans3.sort(comparator.reversed());
		System.out.println(humans3);

//		Sort With Multiple Conditions
		List<Human> humans4 = Arrays.asList(new Human("ravi", 12), new Human("hemanth", 10), new Human("avi", 6));
		humans4.sort((h1, h2) -> {
			if (h1.getName().equals(h2.getName())) {
				return Integer.compare(h1.getAge(), h2.getAge());
			} else {
				return h1.getName().compareTo(h2.getName());
			}
		});
		System.out.println(humans4);

//		Sort With Multiple Conditions – Composition
		List<Human> humans5 = Arrays.asList(new Human("ravi", 12), new Human("hemanth", 10), new Human("avi", 6));
		humans5.sort(Comparator.comparing(Human::getAge).thenComparing(Human::getName));
		System.out.println(humans5);

	}
}
