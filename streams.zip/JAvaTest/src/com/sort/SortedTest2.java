package com.sort;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

//Sorting a List With Stream.sorted()

//we have two overloaded variants of the sorted() API:
//	1. sorted() – sorts the elements of a Stream using natural ordering; the element class must implement the Comparable interface.
//  2. sorted(Comparator<? super T> comparator) – sorts the elements based on a Comparator instance.
public class SortedTest2 {
	public static void main(String[] args) {
		List<Integer> letters = Arrays.asList(32, 54, 12, 113, 0, 55);
		letters.stream().sorted().forEach(System.out::println);

		List<Human> humans = Arrays.asList(new Human("ravi", 12), new Human("hemanth", 10), new Human("avi", 6));
		Comparator<Human> comparator = (h1, h2) -> h1.getAge().compareTo(h2.getAge());
		humans.stream().sorted(comparator).forEach(System.out::println);

//		Simplify above comparator logic
		List<Human> humans1 = Arrays.asList(new Human("ravi", 12), new Human("hemanth", 10), new Human("avi", 6));
		humans1.stream().sorted(Comparator.comparing(Human::getAge)).forEach(System.out::println);
		
//		Reverse order
//		Note: comparator.reversed() internally calls Collections.reverseOrder(this) method
		List<Human> humans2 = Arrays.asList(new Human("ravi", 12), new Human("hemanth", 10), new Human("avi", 6));
		humans2.stream().sorted(comparator.reversed()).forEach(System.out::println);
		
//		Reverse order
		List<Human> humans3 = Arrays.asList(new Human("ravi", 12), new Human("hemanth", 10), new Human("avi", 6));
		humans3.stream().sorted(Comparator.comparing(Human::getAge).reversed()).forEach(System.out::println);
		
//		simplify reverse order
		List<Human> humans4 = Arrays.asList(new Human("ravi", 12), new Human("hemanth", 10), new Human("avi", 6));
		humans4.stream().sorted(Comparator.comparing(Human::getAge, Comparator.reverseOrder()));

//		sort based on length of the names.
		List<Human> humans5 = Arrays.asList(new Human("ravi", 12), new Human("hemanth", 10), new Human("avi", 6));
//		Way-- 1
		Collections.sort(humans5, Comparator.comparingInt(h -> h.getName().length()));
//		Way-- 2
		humans5.stream().sorted(Comparator.comparing(h -> h.getName().length())).forEach(System.out::println);
//		Way-- 3
		Comparator<Human> com = (h1,h2) -> h1.getName().length() - h2.getName().length();
		humans5.stream().sorted(com).forEach(System.out::println);
//		Way-- 4
		humans5.sort(com);
	}
}
