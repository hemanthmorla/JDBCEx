package com.binaryOperator;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.BinaryOperator;

public class BinaryOperatorTest2 {
	public static void main(String[] args) {
		Employee emp1 = new Employee("hemanth", BigDecimal.valueOf(9999));
		Employee emp2 = new Employee("Raju", BigDecimal.valueOf(8888));
		Employee emp3 = new Employee("Naresh", BigDecimal.valueOf(10000));
		Employee emp4 = new Employee("Ravi", BigDecimal.valueOf(2000));
		Employee emp5 = new Employee("Guru", BigDecimal.valueOf(1000));

		List<Employee> empList = Arrays.asList(emp1, emp2, emp3, emp4, emp5);
// 		Any Getter method can acts like a Function, emp object as input and salary is output.
		Comparator<Employee> comparator = Comparator.comparing(Employee::getSalary);

		BinaryOperator<Employee> maxBy = BinaryOperator.maxBy(comparator);
		BinaryOperator<Employee> minBy = BinaryOperator.minBy(comparator);

		Employee maxSalaryEmp = find(empList, maxBy);
		System.out.println(maxSalaryEmp);

		Employee minSalaryEmp = find(empList, minBy);
		System.out.println(minSalaryEmp);
	}

	public static Employee find(List<Employee> emplist, BinaryOperator<Employee> accumulator) {
		Employee result = null;
		for (Employee employee : emplist) {
			if (result == null) {
				result = employee;
			} else {
				result = accumulator.apply(employee, result);
			}
		}
		return result;
	}
}
