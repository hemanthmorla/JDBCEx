package com.binaryOperator;

import java.util.function.BiFunction;
import java.util.function.BinaryOperator;

//The BinaryOperator takes two arguments of the same type and returns a result of the same type of its arguments.
//@FunctionalInterface
//public interface BinaryOperator<T> extends BiFunction<T,T,T> {
//}

public class BinaryOperatorTest {
	public static void main(String[] args) {
		BiFunction<Integer, Integer, Integer> biFun = (x, y) -> x + y;
		Integer result = biFun.apply(2, 3);
		System.out.println(result);
		
		BinaryOperator<Integer> result1 = (x,y) -> x + y;
		Integer output = result1.apply(2, 3);
		System.out.println(output);
	}
}
