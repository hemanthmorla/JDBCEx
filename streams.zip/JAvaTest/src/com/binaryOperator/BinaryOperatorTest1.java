package com.binaryOperator;

import java.util.Arrays;
import java.util.List;
import java.util.function.BinaryOperator;

public class BinaryOperatorTest1 {
	public static <T> T math(List<T> list, T init ,BinaryOperator<T> accumulator) {
		T result = init;
		for (T t : list) {
			result = accumulator.apply(result, t);
		}
		return result;
	}

	public static void main(String[] args) {
		Integer[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
		List<Integer> numList = Arrays.asList(numbers);
		Integer result1 = math(numList,0, (x, y) -> x + y);
		System.out.println(result1);
		Integer result2 = math(Arrays.asList(numbers), 0,Integer::sum);
		System.out.println(result2);
	}
}
