package com.unaryoperator;

import java.util.function.Function;
import java.util.function.UnaryOperator;

//The UnaryOperator takes one argument, and returns a result of the same type of its arguments.
//@FunctionalInterface
//	public interface UnaryOperator<T> extends Function<T, T> {
//}
public class UnaryOperatorTest {
	public static void main(String[] args) {
		Function<Integer, Integer> fun = x -> x + x;
		Integer funResult = fun.apply(3);
		System.out.println(funResult);

		UnaryOperator<Integer> unaryOp = x -> x + x;
		Integer unaryResult = unaryOp.apply(3);
		System.out.println(unaryResult);
	}
}
