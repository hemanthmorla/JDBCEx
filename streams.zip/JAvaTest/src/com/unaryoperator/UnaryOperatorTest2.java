package com.unaryoperator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.UnaryOperator;

// method chaining
public class UnaryOperatorTest2 {
	static <T> List<T> math(List<T> list, UnaryOperator<T> uo, UnaryOperator<T> uo2) {
		List<T> result = new ArrayList<>();
		for (T t : list) {
			T output = uo.andThen(uo2).apply(t);
			result.add(output);
		}
		return result;
	}
	
	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
		List<Integer> result = math(list, x -> x*x , x -> x+2);
		System.out.println(result);
	}
}
