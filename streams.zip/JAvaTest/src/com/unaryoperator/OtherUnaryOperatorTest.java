package com.unaryoperator;

import java.util.function.DoubleUnaryOperator;
import java.util.function.IntUnaryOperator;
import java.util.function.LongUnaryOperator;

public class OtherUnaryOperatorTest {
	public static void main(String[] args) {
		IntUnaryOperator intUnOp = a -> a * a;
		int result = intUnOp.applyAsInt(5);
		System.out.println(result);
		
		DoubleUnaryOperator doubleUnOp = a -> a*a;
		double result1 = doubleUnOp.applyAsDouble(5.0);
		System.out.println(result1);
		
		LongUnaryOperator longUnOp = a -> a*a;
		long result2 = longUnOp.applyAsLong(5);
		System.out.println(result2);
	}
}
