package com.unaryoperator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.UnaryOperator;

public class UnaryOperatorTest1 {
	static <T> List<T> math(List<T> list, UnaryOperator<T> u) {
		List<T> mathList = new ArrayList<>();
		for (T t : list) {
			T output = u.apply(t);
			mathList.add(output);
		}
		return mathList;
	}

	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
		List<Integer> multiplyByTwo = math(list, x -> x * 2);
		System.out.println(multiplyByTwo);
	}
}
