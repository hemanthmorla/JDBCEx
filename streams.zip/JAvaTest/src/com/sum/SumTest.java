package com.sum;

import java.util.Arrays;
import java.util.List;

public class SumTest {
	public static void main(String[] args) {
		List<Integer> integers = Arrays.asList(1, 2, 3, 4, 5);
		Integer reduceSum = integers.stream().reduce(0,(a,b)-> a+b);
		System.out.println(reduceSum);
	}
}
