package com.intstream;

import java.util.stream.IntStream;

public class IntStreamTest {
	public static void main(String[] args) {
		 IntStream.of(1, 2, 3, 4)
		 	.peek(System.out::println).count();
		
		int sum = IntStream.of(1, 2, 3, 4)
        .filter(e -> e > 2)
        .peek(e -> System.out.println("Filtered value: " + e))
        .map(e -> e * e)
        .peek(e -> System.out.println("Mapped value: " + e))
        .sum();
		System.out.println(sum);
	}
}
