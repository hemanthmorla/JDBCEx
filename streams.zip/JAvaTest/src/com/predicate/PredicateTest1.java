package com.predicate;

import java.util.function.Predicate;

public class PredicateTest1 {
	public static void main(String[] args) {
//		Way-- 1 => Plain Predicate
		Predicate<String> isLongWord = new Predicate<String>() {
			@Override
			public boolean test(String str) {
				return str.length() > 5;
			}
		};
		String s = "Test Predicate Program";
		boolean result = isLongWord.test(s);
		System.out.println(result);
		
//		Way-- 2
		Predicate<String> isALongWord1 = t -> t.length() > 5;
		String s1 = "Test Predicate Program";
		boolean result1 = isALongWord1.test(s1);
		System.out.println(result1);
	}
}
