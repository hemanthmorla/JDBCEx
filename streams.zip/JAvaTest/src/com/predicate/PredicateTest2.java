package com.predicate;

import java.util.function.Predicate;

//Predicate Chain and methods.
public class PredicateTest2 {
	public static void main(String[] args) {

		Predicate<Integer> lessThan = (i) -> i < 20;
		Predicate<Integer> greaterThan = (i) -> i > 10;
//		and
		System.out.println(greaterThan.and(lessThan).test(12));
		System.out.println(greaterThan.and(lessThan).test(122));
//		or
		System.out.println(greaterThan.or(lessThan).test(300));
		System.out.println(greaterThan.or(lessThan).test(1));
//		Predicate as argument
		pred(22, i -> i > 20);
//		negate
		Predicate<String> predicate = t -> t.length() > 10;
		String str = "abcde";
		boolean outcome = predicate.negate().test(str);
		System.out.println(outcome);
//		not
		Predicate<String> notPredicate = Predicate.not(predicate);
		System.out.println(notPredicate.test(str));
//		Note: The not() and negate() methods in Java 8 both negate a predicate.
//		not():
//				is a static method on the Predicate interface. 
//				It takes a predicate as an argument and returns a new predicate that is the negation of the original predicate.
//		negate():
//				is an instance method on the Predicate interface. 
//				It returns a new predicate that is the negation of the original predicate.
		
//		equal():
//		The equals() method in Predicate Java 8 is a static method that returns a predicate 
//		that tests whether the object reference being tested is equal to the target reference, based on the equals method.
		// Create a predicate that tests if two strings are equal.
        Predicate<String> equalsPredicate = Predicate.isEqual("SomeString");

        boolean isEqual1 = equalsPredicate.test("SomeString");
        boolean isEqual2 = equalsPredicate.test("AnotherString");

        System.out.println(isEqual1); 
        System.out.println(isEqual2); 
	}

	static void pred(int number, Predicate<Integer> predicate) {
		if (predicate.test(number)) {
			System.out.println("Number " + number);
		}
	}
}
