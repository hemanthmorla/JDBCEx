package com.bifunction;

import java.util.function.BiFunction;
import java.util.function.Function;

//This BiFunction takes two Integer and returns a Double, and uses andThen() to chain it with a Function to convert the Double into a String.
public class BiFunctionTest1 {

//	Case: 1
//	public static void main(String[] args) {
//		BiFunction<Integer, Integer, Double> biFun = (x, y) -> Math.pow(x, y);
//		Function<Double, String> fun = (z) -> "Result is " + String.valueOf(z);
//
//		String output = biFun.andThen(fun).apply(3, 4);
//		System.out.println(output);
//	}

//	End Case 1

//	Case: 2
//	public static void main(String[] args) {
//		String output = powToString(3, 4, (x, y) -> Math.pow(x, y), (z) -> "Result is :" + String.valueOf(z));
//		System.out.println(output);
//	}
//
//	public static String powToString(Integer x, Integer y, BiFunction<Integer, Integer, Double> biFun,
//			Function<Double, String> fun) {
//		return biFun.andThen(fun).apply(x, y);
//	}

//	End Case 2

//	Case: 3
	public static void main(String[] args) {
		String output1 = powToString(3, 4, (x, y) -> Math.pow(x, y), (z) -> "Result is :" + String.valueOf(z));
		System.out.println(output1);
		Double output2 = powToString(3, 4, (x, y) -> Math.pow(x, y), (z) -> z * z);
		System.out.println(output2);
	}

	// here we are making output as generic <R>.. For more see BiFunctionTest2.java
	public static <R> R powToString(Integer x, Integer y, BiFunction<Integer, Integer, Double> biFun,
			Function<Double, R> fun) {
		return biFun.andThen(fun).apply(x, y);
	}

//	End Case 3
}
