package com.bifunction;

import java.util.function.BiFunction;
import java.util.function.Function;

public class BiFunctionTest2 {
	
	public static void main(String[] args) {
		// Take two Integers, pow it into a Double, convert Double into a String.
		String output1 = convert(3, 4, (x,y) -> Math.pow(x, y), (r) -> "Result is :"+String.valueOf(r));
		System.out.println(output1);
		
		 // Take two Integers, multiply into an Integer, convert Integer into a String.
		String output2 = convert(3, 4, (x,y) -> x*y , (z) -> "Result is :"+ String.valueOf(z));
		System.out.println(output2);
		
		// Take two Strings, join both, join "-Avi"
		String output3 = convert("Hemanth", "-Jyothi", (s1,s2)-> s1+s2, (s3)-> s3+"-Avi");
		System.out.println(output3);
		
		// Take two Strings, join both, convert it into an Integer
		Integer output4 = convert("100", "200", (a,b) -> a+b , (c) -> Integer.valueOf(c) );
		System.out.println(output4);
		
	}
	
	public static <X, Y, R1, R2> R2 convert(X x, Y y, BiFunction<X, Y, R1> biFun, Function<R1, R2> fun) {
		return biFun.andThen(fun).apply(x, y);
	}
}

