package com.bifunction;

import java.util.function.BiFunction;
import java.util.function.Function;

public class BiFunctionTest3 {

	public static <A,B,R> R biFuncFactory(A latitude, B longitude, BiFunction<A, B, R> biFunc) {
		return biFunc.apply(latitude, longitude);
	}
	
	public static <A,R> R funFactory(A latitude, Function<A,R> func) {
		return func.apply(latitude);
	}
	
	public static void main(String[] args) {
//		The GPS::new calls the constructor, which accepts two arguments and return an object (GPS), so it matches with the BiFunction signature.
		Gps gps = biFuncFactory("1.23", "3.45", Gps::new);
		System.out.println(gps);
		Gps gps2 = biFuncFactory(1, 2, Gps::new);
		System.out.println(gps2);
//		The GPS::new calls the constructor, which accepts one argument and return an object (GPS), so it matches with the Function signature.
		Gps gps3 = funFactory("3.45", Gps::new);
		System.out.println(gps3);
	}
}
