package com.bifunction;

import java.util.Objects;

public class Gps {
	private String Latitude;
	private String Longitude;

	public Gps(String latitude, String longitude) {
		super();
		Latitude = latitude;
		Longitude = longitude;
		System.out.println("Inside string con");
	}

	public Gps(int latitude, int longitude) {
		super();
		Latitude = "";
		Longitude = "";
		System.out.println("Inside int con");
	}

	public Gps(String latitude) {
		super();
		Latitude = latitude;
		System.out.println("Inside latitude con");
	}

	public String getLatitude() {
		return Latitude;
	}

	public void setLatitude(String latitude) {
		Latitude = latitude;
	}

	public String getLongitude() {
		return Longitude;
	}

	public void setLongitude(String longitude) {
		Longitude = longitude;
	}

	@Override
	public int hashCode() {
		return Objects.hash(Latitude, Longitude);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Gps other = (Gps) obj;
		return Objects.equals(Latitude, other.Latitude) && Objects.equals(Longitude, other.Longitude);
	}

	@Override
	public String toString() {
		return "Gps [Latitude=" + Latitude + ", Longitude=" + Longitude + "]";
	}

}
