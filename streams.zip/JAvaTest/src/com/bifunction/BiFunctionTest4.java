package com.bifunction;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.BiFunction;

public class BiFunctionTest4 {
	public static void main(String[] args) {

		BiFunctionTest4 obj = new BiFunctionTest4();
		List<String> list = Arrays.asList("node", "c++", "java", "javascript");
		list.stream().forEach(System.out::println);
//		Filter By Length
//		Way-- 1
//		The obj::filterByLength matches with the BiFunction signature.
		List<String> result = obj.filterList(list, 3, obj::filterByLength);
		System.out.println("Way-1: " + result);
//		Way-- 2
//		Here we have written explict Bifunction and passed it as parameter
		BiFunction<String, Integer, String> biFunc = (str, size) -> {
			if (str.length() > size) {
				return str;
			} else {
				return null;
			}
		};
		List<String> result1 = obj.filterList(list, 3, biFunc);
		System.out.println("Way-2: " + result1);
//		Way-- 3
//		Here we have written implict Bifunction inside the method
		List<String> result2 = obj.filterList(list, 3, (l1, size) -> {
			if (l1.length() > size) {
				return l1;
			} else {
				return null;
			}
		});
		System.out.println("Way-3: " + result2);
//		Filter by Starting char
		List<String> result3 = obj.filterList(list, "c", (l1, condition) -> {
            if (l1.startsWith(condition)) {
                return l1;
            } else {
                return null;
            }
        });
		System.out.println(result3);
	}

	public <T, U, R> List<R> filterList(List<T> list1, U condition, BiFunction<T, U, R> func) {
		List<R> result = new ArrayList<>();
		for (T t : list1) {
			R apply = func.apply(t, condition);
			if (apply != null) {
				result.add(apply);
			}
		}
		return result;
	}

	public String filterByLength(String str, Integer size) {
		if (str.length() > size) {
			return str;
		} else {
			return null;
		}
	}

}
