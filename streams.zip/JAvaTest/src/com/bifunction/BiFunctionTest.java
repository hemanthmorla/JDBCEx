package com.bifunction;

import java.util.function.BiFunction;

public class BiFunctionTest {
	public static void main(String[] args) {
		BiFunction<Integer, Integer, Integer> fun1 = (x, y) -> x + y;
		Integer output1 = fun1.apply(3, 4);
		System.out.println(output1);

		BiFunction<Integer, Integer, Double> fun2 = (x, y) -> Math.pow(x, y);
		Double output2 = fun2.apply(3, 4);
		System.out.println(output2);
	}
}
