package com.extra;

public class CustomFunctionalInterfaceAddImpl {
	public static void main(String[] args) {
		CustomFunctionalInterfaceAdd func = (a, b) -> a + b;
		int result = func.add(2, 3);
		System.out.println(result);
	}
}
