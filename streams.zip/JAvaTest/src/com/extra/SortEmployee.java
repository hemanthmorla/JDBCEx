package com.extra;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

// Sort Employee list based on salary and then name.
public class SortEmployee {
	public static void main(String[] args) {
		List<Employee> list = new ArrayList<>();
		Employee e1 = new Employee("Raju", 10000);
		Employee e2 = new Employee("Naresh", 2000);
		Employee e3 = new Employee("Hemanth", 30000);
		Employee e4 = new Employee("Guru", 30000);
		
		list.add(e1);
		list.add(e2);
		list.add(e3);
		list.add(e4);
		
		Comparator<Employee> compBySal = (emp1,emp2) -> emp1.getSalary().compareTo(emp2.getSalary());
		Comparator<Employee> compByName = (emp1,emp2) -> emp1.getName().compareTo(emp2.getName());
		Comparator<Employee> finalComp = compBySal.thenComparing(compByName);
		list.sort(finalComp);
		System.out.println(list);
		
		list.stream().sorted(finalComp).forEach(System.out::println);
	
	}
}
