package com.extra;

import java.util.HashMap;
import java.util.Map;

public class PrintMap {
	public static void main(String[] args) {
		Map<String, String> map = new HashMap<>();
		map.put("a", "hemanth");
		map.put("b", "Ravi");
		
		map.forEach((key,value) -> {
			System.out.println(key +"--"+ value);
		});
	}
}
