package com.extra;

public class CustomFunctionalInterfaceImpl {
	public static void main(String[] args) {
		// Using Anonymous inner class
		CustomFunctionalInterface fun = new CustomFunctionalInterface() {
			@Override
			public void display() {
				System.out.println("Inside display() method");
			}
		};
		fun.display();
		
		// Using Lambda Expression
		CustomFunctionalInterface fun1 = () -> System.out.println("Inside display() method lambda");
		fun1.display();
	}
}
