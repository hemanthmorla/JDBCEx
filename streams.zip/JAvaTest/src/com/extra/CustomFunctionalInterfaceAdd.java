package com.extra;

@FunctionalInterface
public interface CustomFunctionalInterfaceAdd {
	int add(int a, int b);
}
