package com.extra;

@FunctionalInterface
public interface CustomFunctionalInterface {
	void display();
}
