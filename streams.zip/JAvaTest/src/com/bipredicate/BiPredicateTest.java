package com.bipredicate;

import java.util.function.BiPredicate;

public class BiPredicateTest {
	public static void main(String[] args) {
		BiPredicate<String, Integer> biPre = (x, y) ->  (x.length() == y);
		
		boolean test = biPre.test("hemanth", 7);
		System.out.println(test);
	}
}
