package com.test.count;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HitCountServlet
 */
@WebServlet("/HitCountServlet")
public class HitCountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter out = resp.getWriter();
		ServletContext context = getServletContext();
		Integer count = (Integer) context.getAttribute("hitcount");
		if (count == null) {
			count = 1;
		} else {
			count++;
		}
		context.setAttribute("hitcount", count);
		out.println("<h1>The number of requests are: " + count + "</h1>");
	}

}
