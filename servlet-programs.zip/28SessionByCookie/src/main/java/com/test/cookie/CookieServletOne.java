package com.test.cookie;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CookieServletOne
 */
@WebServlet("/CookieServletOne")
public class CookieServletOne extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter out = res.getWriter();
		String name = req.getParameter("uname");
		String value = req.getParameter("uvalue");
		Cookie c = new Cookie(name, value);
		c.setMaxAge(180);
		res.addCookie(c);
		out.println("<h2>Cookie added successfully</h2>");
		RequestDispatcher rd = req.getRequestDispatcher("cookie.html");
		rd.include(req, res);
	}

}
