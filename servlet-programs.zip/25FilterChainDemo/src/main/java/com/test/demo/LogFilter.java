package com.test.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;

public class LogFilter extends HttpFilter implements Filter {
	private FilterConfig config;

	public void init(FilterConfig fConfig) throws ServletException {
		this.config = fConfig;
	}

	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain)
			throws IOException, ServletException {
		PrintWriter out = resp.getWriter();
		out.println("<h1> This Line added by log Filter before processing of the request</h1>");
		ServletContext context = config.getServletContext();
		HttpServletRequest req1 = (HttpServletRequest) req;
		// this statement prints on console as log statement. Observe console here.
		context.log("A request is coming from " + req1.getRemoteHost() + " for URL :" + req1.getRequestURL() + " at "
				+ new Date());
		chain.doFilter(req, resp);
		out.println("<h1> This Line added by Log Filter After processing of the request</h1>");
	}
	
	public void destroy() {
		this.config=null;
	}

}
