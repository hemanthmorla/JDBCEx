package com.test.http;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/HttpServiceTest")
public class HttpServiceTest extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter out = resp.getWriter();
		String method = req.getMethod();
		if (method.equals("GET")) {
			System.out.println("Going to get data from doGet() method... Hurry!!!");
			out.println("<h1>Going to get data fomr doGet() method... Hurry!!!</h1>");
			doGet(req, resp);
		} else if (method.equals("POST")) {
			System.out.println("Going to get data fomr doPost() method... Hurry!!!");
			out.println("<h1>Going to get data fomr doPost() method... Hurry!!!</h1>");
			doPost(req, resp);
		}
		else {
			out.println("<h1>Learn valid http methods first...!!!</h1>");
		}
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("<h1>This is from doGET()method...</h1>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("<h1>This is from doPOST()method...</h1>");
	}
}
