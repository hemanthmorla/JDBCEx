package com.test.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class FilterDemo implements Filter {
	private static final long serialVersionUID = 1L;

	public void init(FilterConfig filterConfig) throws ServletException {
		System.out.println("Inside init() method of FilterDemo...!!!");
	}

	public void destroy() {
		System.out.println("Inside destroy() method of FilterDemo...!!!");
	}

	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain fc)
			throws ServletException, IOException {
		PrintWriter out = resp.getWriter();
		out.println("<h1>This line added by Demo Filter before processing the request</h1>");
		fc.doFilter(req, resp);
		out.println("<h1>This line added by Demo Filter after processing the request</h1>");
	}
}
