package com.test.context;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletContextDemo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter out = resp.getWriter();
		out.println("<html>");
		out.println("<center><h1>Intialization Parameters</h1></center><hr>");
		ServletContext context = getServletContext();
		Enumeration e = context.getInitParameterNames();
//		String value=getServletConfig().getInitParamter("user"); Try this by commenting out above line.
		out.println("<table border=2><tr><th>Parameter Name</th><th>Parameter Value</th></tr>");
		while (e.hasMoreElements()) {
			String pname = (String) e.nextElement();
			String pvalue = context.getInitParameter(pname);
			out.println("<tr><td>" + pname + "</td><td>" + pvalue + "</td></tr>");
		}
		out.println("</table>");
		out.println("</body></html>");
	}
}
