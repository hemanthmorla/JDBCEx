package com.test.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DisplayAttributesDemo")
public class DisplayAttributesDemo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("<h1>Context Attributes</h1>");
		ServletContext context = getServletContext();
		context.setAttribute("Training", "Servlet");
		context.setAttribute("Org", "Cognovision");
		Enumeration e = context.getAttributeNames();

		while (e.hasMoreElements()) {
			String name = (String) e.nextElement();
			Object value = context.getAttribute(name);
			out.println(name + "....." + value + "<br>");
		}
	}

}
