package com.test.requestheader;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class SessionServletOne
 */
@WebServlet("/SessionServletOne")
public class SessionServletOne extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter out = res.getWriter();
		HttpSession hs = req.getSession();
		if (hs.isNew()) {
			out.println("<html>");
			out.println("<h2>New Session got created with session ID:" + hs.getId() + "</h2>");
			out.println("</html>");
		} else {
			out.println("<html>");
			out.println("<h2>Existing Session only using with session ID:" + hs.getId() + "</h2>");
			out.println("</html>");
		}
		String name = req.getParameter("uname");
		String value = req.getParameter("uvalue");
		hs.setAttribute(name, value);
		// hs.setMaxInactiveInterval(120);
		RequestDispatcher rd = req.getRequestDispatcher("login.html");
		rd.include(req, res);
	}
}
