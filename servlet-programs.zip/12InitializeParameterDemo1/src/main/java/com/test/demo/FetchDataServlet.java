package com.test.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// Note: Include ojdbc11.jar into apache-tomcat-9.0.87\lib folder.

public class FetchDataServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username = getInitParameter("user");
		String password = getInitParameter("password");

		PrintWriter out = response.getWriter();
		try {
			String sql_query = "select * from emp";
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/XE", username, password);
			PreparedStatement prepareStatement = con.prepareStatement(sql_query);
			ResultSet resultSet = prepareStatement.executeQuery();
			out.println("<html>");
			out.println("<center><h1>Employees data</h1></center><hr>");
			out.println("<table border=2><tr><th>EmpNo</th><th>EmpName</th><th>JOB</th><th>Salary</th> </tr>"); 
			while (resultSet.next()) {
				out.println("<tr>"
						+ "<td>" + resultSet.getString("empno") + "</td><td>" + resultSet.getString("ename")
						+ "</td><td>" + resultSet.getString("job") + "</td><td>" + resultSet.getString("sal")
						+ "</td></tr>");
			}
			out.println("</table>");
			out.println("</body></html>");
		} catch (Exception e) {
			System.out.println("Error Occured");
		}
	}
}
