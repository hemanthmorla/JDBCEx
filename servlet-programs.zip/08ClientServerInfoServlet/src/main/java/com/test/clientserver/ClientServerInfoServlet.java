package com.test.clientserver;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ClientServerInfoServlet")
public class ClientServerInfoServlet extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter out = resp.getWriter();
		out.println("<h1>Client IP Address:" + req.getRemoteAddr() + "</h1>");
		out.println("<h1>Client Host:" + req.getRemoteHost() + "</h1>");
		out.println("<h1>Client Port:" + req.getRemotePort() + "</h1>");
		out.println("<h1>Server Name:" + req.getServerName() + "</h1>");
		out.println("<h1>Server Port:" + req.getServerPort() + "</h1>");
	}
}
