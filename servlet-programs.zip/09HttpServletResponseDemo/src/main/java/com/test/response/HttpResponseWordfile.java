package com.test.response;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/HttpResponseWordfile")
public class HttpResponseWordfile extends HttpServlet {
	public void doGet(HttpServletRequest req,HttpServletResponse resp) throws ServletException,IOException 
	{ 
	PrintWriter out = resp.getWriter(); 
	resp.setContentType("application/msword"); 
	out.println("<h1><table border=1>"); 
	out.println("<tr><th>NAME</th><th>RANK</th></tr>"); 
	out.println("<tr><td>Chiru</td><td>1</td></tr>"); 
	out.println("<tr><td>Balakrishna</td><td>2</td></tr>"); 
	out.println("<tr><td>Nagarjuna</td><td>3</td></tr>"); 
	out.println("<tr><td>Venaktesh</td><td>4</td></tr></h1>"); 
	}
}
